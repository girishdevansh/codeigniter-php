<?php

	$message =
   "This mail only for test";


$to="gc000160@gmail.com";

require("mailer/class.phpmailer.php");


$mail = new PHPMailer;
$mail->IsSMTP();                              
$mail->Host = "smtp.gmail.com";                
                
$mail->Port = 587;                                   
$mail->SMTPAuth = true;                             
$mail->Username = "gc000160@gmail.com";             
$mail->Password = "mymzidkchiqvwwqa";             
                    
$mail->From = 'gc000160@gmail.com';
$mail->FromName = 'Akashblowers';
$mail->AddAddress($to); 
$mail->AddCC('gc000160@gmail.com');
$mail->IsHTML(true);                              
$mail->Subject = 'This is for test';
$mail->Body    = $message;
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

//$send=$mail->Send(); 
if(!$mail->send()){
    print_r($mail);
    echo 'Mailer Error: ' . $mail->ErrorInfo;
}else{
    echo 'The email message was sent.';
}

		








?>
