<?php
//$conn=mysqli_connect('localhost','lookyoun_enqu','fsc_dev@123','lookyoun_enquiry');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';



$Message =  "Test";
	
				 
$mail = new PHPMailer();
$mail->IsSMTP(true);
//$mail->SMTPDebug  = 2;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl'; 
$mail->Port = 465;
$mail->From ="ngilgzb@gmail.com";
$mail->FromName = 'Test';
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username = 'ngilgzb@gmail.com';
//$mail->Password = 'mgdihzyeewbreute'; 
// $mail->Password = 'mymzidkchiqvwwqa';
$mail->Password = 'nhkoaqpqllevqvee'; 

$mail->AddReplyTo = 'gc000160@gmail.com';
$mail->AddAddress("gc000160@gmail.com");

$mail->AddCc("ngilgzb@modisteel.net");

$mail->Subject = "Test";
$mail->Body    =stripcslashes($Message);
$mail->IsHTML(true);
$xmail_=$mail->Send();
if($xmail_)
{

echo "Sent";


 }
else
{
	print_r($mail);
    echo 'Mailer Error: ' . $mail->ErrorInfo;
?>
	
<?php
}
	
?>		