<?php
session_start();
if(isset($_POST['contact']))
{
if(isset($_POST["norobot"]) && $_POST["norobot"]!="" && $_SESSION["code"]==$_POST["norobot"])
{
               $held_in = implode(',', $_POST['held_in']);
               $awards = implode(',', $_POST['awards']);
               $category = $_POST['category'];
               $applicant_name = $_POST['applicant_name'];
               $designation = $_POST['designation'];
               $company = $_POST['company'];
               $gender = $_POST['gender'];
               $dob = $_POST['date'];
               $address = $_POST['address'];
               $city = $_POST['city'];
               $state = $_POST['state'];
               $pincode = $_POST['pincode'];
               $telephone = $_POST['telephone'];
               $mobile = $_POST['mobile'];
               $email = $_POST['email'];
               $website = $_POST['website'];
               $yoi = $_POST['yoi'];
               $headoffice = $_POST['headoffice'];
               $csr = $_POST['csr'];
               $achievement = $_POST['achievement'];
               $operating_add = $_POST['operating_add'];
               $noofemployee = $_POST['noofemployee'];
               $legal_status = implode(',', $_POST['legal_status']);
               $services = $_POST['services'];
               $document = $_POST['document'];
               $affiliation = $_POST['affiliation'];
               $description = $_POST['description'];
               $refby = $_POST['refby'];
$store="N/A";
if(!empty($img_name=$_FILES['file']['name']))
{
$img_tmp=$_FILES['file']['tmp_name'];
//list($width, $height, $type, $attr) = getimagesize($_FILES['image']['tmp_name']);
$img_extension=explode(".",$img_name);
$img_extension=strtolower(end($img_extension));
$img_new_name=uniqid().'.'.$img_extension;
$store="img/attach/".$img_new_name;
}

$message =
"<html>
<head>
    <title>Enquiry : Aero India 2019</title>
</head>
<body>
    <table width='100%' border='0' cellspacing='0' cellpadding='0' style='border: #1a7fc0 solid 10px; padding: 15px;'>
        <tbody>
            <tr>
                <td>
                    <table width='100%' border='0' cellspacing='2' cellpadding='2'>
                        <tr>
                            <td style='background-color: #fff;'>
                                <br />
                                <img src='img/logo.png' width='90' />
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr>
                <td style='font-size: 14px; padding: 0px 20px 20px 20px; color: #333333;'>
                    <hr />
                    <br />
                    <br />
                    <div style='line-height: 18px; font-size: 14px'>
                        <table cellpadding='4' cellspacing='4' width='100%' style='text-align:center;'>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Nationality : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $held_in
                                </td>
                                <td style='width:25%;'>
                                    <strong>Award Type : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $awards
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Category : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $category
                                </td>
                                <td style='width:25%;'>
                                    <strong>Gender : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $gender
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Name of the appplicant : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $applicant_name
                                </td>
                                <td style='width:25%;'>
                                    <strong>Designation of the applicant : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $designation
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Name of the company : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $company
                                </td>

                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Date Of Birth : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $dob
                                </td>
                                <td style='width:25%;'>
                                    <strong>Address : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $address,$city
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>State : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp;  $state- $pincode
                                </td>
                                <td style='width:25%;'>
                                    <strong>Telephone : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $telephone
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Mobile : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $mobile
                                </td>
                                <td style='width:25%;'>
                                    <strong>Email : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $email
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Website : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $website
                                </td>
                                <td style='width:25%;'>
                                    <strong>Year of Incorporation : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $yoi
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>City of registration : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $headoffice
                                </td>
                                <td style='width:25%;'>
                                    <strong>Social Activities if any : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $csr
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Achievements of Individual/Company : </strong>
                                </td>
                                <td style='width:25%'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $achievement
                                </td>
                                <td style='width:25%;'>
                                    <strong>Countries / Cities of operations : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $operating_add
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Number of Employees : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $noofemployee
                                </td>
                                <td style='width:25%;'>
                                    <strong>Legal status of the company : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $legal_status
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>Please specify name of products : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $services
                                </td>
                                <td style='width:25%'>
                                    <strong>Brief Description of your Organization : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $description
                                </td>
                            </tr>
                            <tr>
                                <td style='width: 25%; '>
                                    <strong>List of Documents enclosed: : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $document - <a href='$store'>download</a>
                                </td>
                                <td style='width:25%;'>
                                    <strong>Affiliation/Recognition from any other : : </strong>
                                </td>
                                <td style='width:25%;'>
                                    &nbsp;&nbsp;&nbsp;&nbsp; $affiliation
                                </td>
                            </tr>
                        </table>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
    <div style=' padding: 15px;'>
        <b>Thanks and Regards,</b><br />
        Support team<br />
        ECONOMIC DEVELOPMENT FORUM
    </div>
    <div><b>** Note: </b>Please do not reply to this email as it is a computer generated email.</div>
    <div><b>** REF BY: </b>$refby</div>
</body>
</html>";

    $to="prakashkmr192@gmail.com";
            
            require("mailer/class.phpmailer.php");
            $mail = new PHPMailer;

$mail->IsSMTP();                                      // Set mailer to use SMTP
$mail->Host = "edfindia.com";                 // Specify main and backup server
//$mail->Host = "202.143.99.95";                 // If the above does not work.
$mail->Port = 587;                                    // Set the SMTP port
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = "no-reply@edfindia.com";                // SMTP username
$mail->Password = "Luckybabu1@#";                  // SMTP password
//$mail->SMTPSecure = "ssl";                            // Enable encryption, 'ssl' also accepted

$mail->From = 'no-reply@edfindia.com';
$mail->FromName = 'edfindia';
$mail->AddAddress($to);  // Add a recipient
//$mail->AddCC('shashikmr750@gmail.com', 'nairaahen.com');

$mail->IsHTML(true);                                  // Set email format to HTML

$mail->Subject = 'One new Application for Nomination';
$mail->Body    = $message;
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
            
            
            if(!$mail->Send()) 
            {
              echo '<script>alert("Oops Error Occured");</script>';
            } 
            else
            {
              echo "<script>alert('Thank you!');</script> ";
              echo "<script>window.location.href='$_SERVER[HTTP_REFERER]';</script> ";
            }
}
else
{
    echo "<script>alert('Invalid Captcha!');</script> ";
    echo "<script>window.location.href='$_SERVER[HTTP_REFERER]';</script> ";
}
}

?>
